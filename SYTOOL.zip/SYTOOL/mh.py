import os
import struct

# 定义颜色常量
NOCOLOR = '\033[0m'
RED = '\033[1;31m'
GREEN = '\033[1;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
LIGHTBLUE = '\033[1;34m'
WHITE = '\033[1;37m'


def modify_file_hex(file_path, A, B):
    search_seq1 = bytes.fromhex(A)
    search_seq2 = bytes.fromhex(B)
    offset_before_search_seq = 0

    try:
        with open(file_path, 'rb') as file:
            file_contents = file.read()
    except FileNotFoundError:
        print(f"{RED}错误：文件 {file_path} 未找到。{NOCOLOR}")
        return

    search_index1 = file_contents.find(search_seq1)
    search_index2 = file_contents.find(search_seq2)

    if search_index1 == -1:
        print(f"{RED}错误：未找到十六进制序列 {A}。{NOCOLOR}")
        return
    if search_index2 == -1:
        print(f"{RED}错误：未找到十六进制序列 {B}。{NOCOLOR}")
        return

    replace_index1 = search_index1 - offset_before_search_seq
    replace_index2 = search_index2 - offset_before_search_seq

    if replace_index1 < 0 or replace_index2 < 0:
        print(f"{RED}错误：偏移量导致替换位置超出文件开始位置。{NOCOLOR}")
        return

    print(f"{GREEN}第一个偏移位置及值: {hex(replace_index1)}: {' '.join(format(byte, '02x') for byte in file_contents[replace_index1:replace_index1 + 4])}{NOCOLOR}")
    print(f"{GREEN}第二个偏移位置及值: {hex(replace_index2)}: {' '.join(format(byte, '02x') for byte in file_contents[replace_index2:replace_index2 + 4])}{NOCOLOR}")

    new_contents = bytearray(file_contents)
    value_at_replace_index1 = new_contents[replace_index1:replace_index1 + 4]
    value_at_replace_index2 = new_contents[replace_index2:replace_index2 + 4]

    new_contents[replace_index1:replace_index1 + 4] = value_at_replace_index2
    new_contents[replace_index2:replace_index2 + 4] = value_at_replace_index1

    try:
        with open(file_path, 'wb') as outfile:
            outfile.write(new_contents)
    except IOError:
        print(f"{RED}错误：无法写入文件 {file_path}。{NOCOLOR}")
        return

    print(f"{GREEN}正在修改，修改完成{NOCOLOR}")


def process_batch(file_path, code_list):
    """
    批量处理十六进制序列的替换
    :param file_path: 要修改的文件路径
    :param code_list: 包含原始和新的十进制值的列表，每个元素是一个元组 (original_decimal, new_decimal)
    """
    for original_decimal, new_decimal in code_list:
        A = format(original_decimal, '08x')
        B = format(new_decimal, '08x')
        modify_file_hex(file_path, A, B)


def main():
    while True:
        print(f"{LIGHTBLUE}1. 修改美化{NOCOLOR}")
        choice = input("请输入选项：")
        if choice == '1':
            file_path = input(f"{RED}请输入要修改文件路径：{NOCOLOR}")
            txt_file_path = input(f"{LIGHTBLUE}请输入美化配置文件路径：{NOCOLOR}")

            try:
                code_list = []
                with open(txt_file_path, 'r') as txt_file:
                    for line in txt_file:
                        try:
                            original_decimal, new_decimal = map(int, line.split())
                            code_list.append((original_decimal, new_decimal))
                        except ValueError:
                            print(f"{RED}错误：配置文件 {txt_file_path} 格式错误，请确保每行是两个整数。{NOCOLOR}")
                            continue
            except FileNotFoundError:
                print(f"{RED}错误：文件 {txt_file_path} 未找到。{NOCOLOR}")
                continue

            process_batch(file_path, code_list)
        else:
            print(f"{RED}无效选项，请重新输入。{NOCOLOR}")

        exit_choice = input(f"\n{WHITE}是否继续修改？(继续输入 Y，退出输入 N)：{NOCOLOR}")
        if exit_choice.lower() not in ['y', 'yes']:
            print(f"{WHITE}已退出。{NOCOLOR}")
            break


if __name__ == "__main__":
    main()
